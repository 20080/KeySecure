import React, {Component} from 'react';



class List extends Component{
render() {
return(
    <div>
<p>Hello world</p>
    </div>
);

}

}

export default List;