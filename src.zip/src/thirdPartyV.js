import React,{Component} from "react";
import './assets/images/xyzxyz-logo.svg'
import "./assets/images/1603724.jpg"

class thirdPartyV extends Component{

    render() {
        return(

            <div>

                <section className="menu cid-rYRn5v2pnT" nonce="menu" id="menu2-g">


                    <nav
                        className="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm">
                        <button className="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                        </button>
                        <div className="menu-logo">
                            <div className="navbar-brand">
                <span className="navbar-logo">
                    <a href="#">
                       XYZ
                    </a>
                </span>

                            </div>
                        </div>
                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav nav-dropdown" data-app-modern-menu="true">
                                <li className="nav-item">
                                    <a className="nav-link link text-black display-7" href="#">
                                        XYZ.org</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link link text-black display-7" href="#">
                                        About Us
                                    </a>
                                </li>
                            </ul>
                            <div className="navbar-buttons mbr-section-btn">
                                <a className="btn btn-sm btn-primary display-7" href="tel:+1-234-567-8901">
                    <span className="btn-icon mbri-mobile mbr-iconfont mbr-iconfont-btn">
                    </span>
                                    +1-234-567-8901
                                </a>
                            </div>
                        </div>
                    </nav>
                </section>

                <section className="engine"><a href="https://mobirise.info/t">free amp template</a></section>
                <section className="header10 cid-rYRnJkSRkw mbr-fullscreen mbr-parallax-background" id="header10-h">


                    <div className="container">
                        <div className="media-container-column mbr-white p-5 align-left col-lg-8 col-md-10">
                            <h1 className="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">
                                XYZ ORG KYC REQUIRED</h1>

                            <p className="mbr-text pb-3 mbr-fonts-style display-5">We provide services in areas of your
                                interest thats why you exactly came here, but to proceeding any futher please select one
                                of the method for kyc of your choice</p>
                            <div className="mbr-section-btn"><a className="btn btn-md btn-primary display-4"
                                                                href="#">Online via KeyBlock
                                Servers</a>
                                <a className="btn btn-md btn-white-outline display-4" href="#">Traditional
                                    KYC process</a></div>
                        </div>
                    </div>
                </section>

                <section once="footers" className="cid-rYRoMRkjaN" id="footer6-i">


                    <div className="container">
                        <div className="media-container-row align-center mbr-white">
                            <div className="col-12">
                                <p className="mbr-text mb-0 mbr-fonts-style display-7">
                                    © Copyright 2020 XYZ Org- All Rights Reserved certified partner of keyBlock<br/><br/>
                                </p>
                            </div>
                        </div>
                    </div>
                </section>
                <script src="assets/web/assets/jquery/jquery.min.js"/>
                <script src="assets/popper/popper.min.js"/>
                <script src="assets/bootstrap/js/bootstrap.min.js"/>
                <script src="assets/tether/tether.min.js"/>
                <script src="assets/smoothscroll/smooth-scroll.js"/>
                <script src="assets/dropdown/js/nav-dropdown.js"/>
                <script src="assets/dropdown/js/navbar-dropdown.js"/>
                <script src="assets/touchswipe/jquery.touch-swipe.min.js"/>
                <script src="assets/parallax/jarallax.min.js"/>
                <script src="assets/theme/js/script.js"/>

            </div>




        )
    }


}
export default thirdPartyV;